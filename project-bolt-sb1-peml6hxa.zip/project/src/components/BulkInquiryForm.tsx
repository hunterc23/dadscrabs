import React, { useState } from 'react';
import { Users, Send } from 'lucide-react';
import { supabase } from '../utils/supabase';
import { trackEvent } from '../utils/analytics';
import type { BulkInquiry } from '../types';

interface BulkInquiryFormProps {
  onClose?: () => void;
}

const BulkInquiryForm: React.FC<BulkInquiryFormProps> = ({ onClose }) => {
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [businessName, setBusinessName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [shortNote, setShortNote] = useState<string>('Inquiry for bulk crab order pricing and availability');

  const validateForm = () => {
    if (!businessName.trim()) return false;
    if (!phone.trim()) return false;
    if (!email.trim() || !email.includes('@')) return false;
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      alert('Please fill in all required fields with valid information.');
      return;
    }

    setIsSubmitting(true);

    try {
      const bulkData: BulkInquiry = {
        business_name: businessName,
        phone,
        email,
        short_note: shortNote,
      };

      const { error } = await supabase
        .from('bulk_inquiries')
        .insert([bulkData]);

      if (error) {
        console.error('Error submitting bulk inquiry:', error);
        alert('There was an error submitting your inquiry. Please try again.');
        return;
      }

      trackEvent('bulk_inquiry_submitted', { business_name: businessName });
      alert('Bulk inquiry submitted successfully! We\'ll contact you with custom pricing.');
      
      // Reset form
      setBusinessName('');
      setPhone('');
      setEmail('');
      setShortNote('Inquiry for bulk crab order pricing and availability');

      if (onClose) onClose();

    } catch (error) {
      console.error('Error submitting bulk inquiry:', error);
      alert('There was an error submitting your inquiry. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white p-8 rounded-lg shadow-lg">
      <div className="flex items-center space-x-2 mb-6">
        <Users className="h-6 w-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-blue-900">Wholesale Inquiry</h2>
      </div>
      
      <p className="text-gray-600 mb-6">
        Contact us for custom pricing and discounts on bulk orders
      </p>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Business Name *
          </label>
          <input
            type="text"
            value={businessName}
            onChange={(e) => setBusinessName(e.target.value)}
            placeholder="Your business or restaurant name"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Phone Number *
          </label>
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="(xxx) xxx-xxxx"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Email Address *
          </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="business@email.com"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Short Note
          </label>
          <textarea
            value={shortNote}
            onChange={(e) => setShortNote(e.target.value)}
            rows={4}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
            placeholder="Tell us about your bulk order needs..."
          />
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-bold py-4 px-6 rounded-lg transition-colors flex items-center justify-center space-x-2"
        >
          {isSubmitting ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              <span>Submitting...</span>
            </>
          ) : (
            <>
              <Send className="h-5 w-5" />
              <span>Submit Inquiry</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default BulkInquiryForm;