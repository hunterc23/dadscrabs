import React, { useState, useEffect, useRef } from 'react';
import { MapPin, CheckCircle, XCircle, ArrowRight } from 'lucide-react';
import { checkDeliveryLocation } from '../utils/googleMaps';
import { trackEvent } from '../utils/analytics';

interface DeliveryData {
  name: string;
  phone: string;
  address: string;
}

interface DeliveryCheckerProps {
  onVerified?: (data: DeliveryData) => void;
  showTitle?: boolean;
  className?: string;
}

const DeliveryChecker: React.FC<DeliveryCheckerProps> = ({ 
  onVerified, 
  showTitle = true, 
  className = '' 
}) => {
  const [address, setAddress] = useState<string>('');
  const [isChecking, setIsChecking] = useState<boolean>(false);
  const [checkResult, setCheckResult] = useState<{
    isInServiceArea: boolean;
    message: string;
    verifiedAddress: string;
  } | null>(null);
  const [showContactForm, setShowContactForm] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const addressInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Initialize Google Places Autocomplete
    const initializeAutocomplete = () => {
      if (!window.google || !window.google.maps || !window.google.maps.places || !addressInputRef.current) return;

      const autocomplete = new window.google.maps.places.Autocomplete(addressInputRef.current, {
        componentRestrictions: { country: 'us' },
        fields: ['formatted_address'],
        types: ['address'],
      });

      autocomplete.addListener('place_changed', () => {
        const place = autocomplete.getPlace();
        if (place.formatted_address) {
          setAddress(place.formatted_address);
        }
      });
    };

    if (window.google) {
      initializeAutocomplete();
    } else {
      const checkGoogleMaps = setInterval(() => {
        if (window.google) {
          clearInterval(checkGoogleMaps);
          initializeAutocomplete();
        }
      }, 100);

      return () => clearInterval(checkGoogleMaps);
    }
  }, []);

  const handleCheckDelivery = async () => {
    if (!address.trim()) {
      alert('Please enter an address to check.');
      return;
    }

    setIsChecking(true);
    setCheckResult(null);
    setShowContactForm(false);

    try {
      const result = await checkDeliveryLocation(address);
      
      setCheckResult({
        isInServiceArea: result.isInServiceArea,
        message: result.message,
        verifiedAddress: result.address,
      });

      if (result.isInServiceArea) {
        setShowContactForm(true);
      }

      trackEvent('delivery_check', {
        address_verified: result.isInServiceArea,
        service_area: result.isInServiceArea ? 'eastern_shore' : 'outside_area',
      });

    } catch (error) {
      console.error('Error checking delivery location:', error);
      setCheckResult({
        isInServiceArea: false,
        message: 'Error checking address. Please try again.',
        verifiedAddress: address,
      });
    } finally {
      setIsChecking(false);
    }
  };

  const handleProceedToOrder = () => {
    if (!name.trim() || !phone.trim()) {
      alert('Please enter your name and phone number to continue.');
      return;
    }

    const deliveryData: DeliveryData = {
      name: name.trim(),
      phone: phone.trim(),
      address: checkResult?.verifiedAddress || address,
    };

    trackEvent('delivery_verified_proceed', {
      has_name: !!name.trim(),
      has_phone: !!phone.trim(),
    });

    if (onVerified) {
      onVerified(deliveryData);
    }
  };

  const resetChecker = () => {
    setAddress('');
    setCheckResult(null);
    setShowContactForm(false);
    setName('');
    setPhone('');
  };

  return (
    <div className={`bg-white p-6 rounded-lg shadow-lg ${className}`}>
      {showTitle && (
        <div className="flex items-center space-x-2 mb-6">
          <MapPin className="h-6 w-6 text-blue-600" />
          <h2 className="text-2xl font-bold text-blue-900">Check Delivery Location</h2>
        </div>
      )}

      <p className="text-gray-700 mb-6">
        Enter your address to verify if we deliver to your area. We serve all locations east of the Bay Bridge.
      </p>

      {/* Address Input */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Delivery Address
          </label>
          <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3 w-full">
            <input
              ref={addressInputRef}
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Enter your full address..."
              className="w-full sm:flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              disabled={isChecking}
            />
            <button
              onClick={handleCheckDelivery}
              disabled={isChecking || !address.trim()}
              className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-bold py-3 px-6 rounded-lg transition-colors whitespace-nowrap"
            >
              {isChecking ? (
                <div className="flex items-center space-x-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>Checking...</span>
                </div>
              ) : (
                'Check Area'
              )}
            </button>
          </div>
        </div>

        {/* Check Result */}
        {checkResult && (
          <div className={`p-4 rounded-lg border ${
            checkResult.isInServiceArea 
              ? 'bg-green-50 border-green-200' 
              : 'bg-red-50 border-red-200'
          }`}>
            <div className="flex items-start space-x-3">
              {checkResult.isInServiceArea ? (
                <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0 mt-0.5" />
              ) : (
                <XCircle className="h-6 w-6 text-red-600 flex-shrink-0 mt-0.5" />
              )}
              <div>
                <p className={`font-medium ${
                  checkResult.isInServiceArea ? 'text-green-800' : 'text-red-800'
                }`}>
                  {checkResult.isInServiceArea ? 'Delivery Available!' : 'Outside Service Area'}
                </p>
                <p className={`text-sm mt-1 ${
                  checkResult.isInServiceArea ? 'text-green-700' : 'text-red-700'
                }`}>
                  {checkResult.message}
                </p>
                {checkResult.verifiedAddress !== address && (
                  <p className="text-sm text-gray-600 mt-2">
                    <strong>Verified address:</strong> {checkResult.verifiedAddress}
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Contact Form (shown when delivery is available) */}
        {showContactForm && checkResult?.isInServiceArea && (
          <div className="border-t pt-6 mt-6">
            <h3 className="text-lg font-bold text-blue-900 mb-4">
              Great! Let's get your contact information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Your Name *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your name"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="(xxx) xxx-xxxx"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
              <button
                onClick={handleProceedToOrder}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-6 rounded-lg transition-colors flex items-center justify-center space-x-2"
              >
                <span>Proceed to Order</span>
                <ArrowRight className="h-5 w-5" />
              </button>
              <button
                onClick={resetChecker}
                className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-4 px-6 rounded-lg transition-colors"
              >
                Check Different Address
              </button>
            </div>
          </div>
        )}

        {/* Try Again Button (shown when delivery is not available) */}
        {checkResult && !checkResult.isInServiceArea && (
          <div className="flex justify-center">
            <button
              onClick={resetChecker}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition-colors"
            >
              Try Different Address
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default DeliveryChecker;