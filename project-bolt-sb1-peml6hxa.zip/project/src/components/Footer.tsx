import React from 'react';
import { Phone, Mail, MapPin, Anchor } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-blue-900 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div className="flex flex-col items-center md:items-start">
            <div className="flex items-center space-x-2 mb-4">
              <Anchor className="h-6 w-6 text-red-500" />
              <span className="text-xl font-bold">Dads Crabs</span>
            </div>
            <p className="text-blue-200 text-center md:text-left">
              Fresh Maryland blue crabs from the Eastern Shore
            </p>
          </div>

          {/* Contact Info */}
          <div className="flex flex-col items-center md:items-start">
            <h3 className="font-semibold mb-4">Contact Us</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-red-500" />
                <span className="text-blue-200">[INSERT PHONE NUMBER]</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4 text-red-500" />
                <span className="text-blue-200">info@dadscrabs.com</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4 text-red-500" />
                <span className="text-blue-200">Cambridge, MD</span>
              </div>
            </div>
          </div>

          {/* Service Area */}
          <div className="flex flex-col items-center md:items-start">
            <h3 className="font-semibold mb-4">Service Area</h3>
            <ul className="text-blue-200 text-sm space-y-1">
              <li>Cambridge, MD</li>
              <li>Ocean City, MD</li>
              <li>Easton, MD</li>
              <li>Fenwick, DE</li>
              <li>Bethany, DE</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-blue-800 mt-8 pt-6 text-center">
          <p className="text-blue-200 text-sm">
            © 2025 Dads Crabs. All rights reserved. Fresh from Maryland's Eastern Shore.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;