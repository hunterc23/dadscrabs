import React from 'react';
import { Link, useLocation } from 'react-router-dom';

interface NavigationProps {
  className?: string;
  onLinkClick?: () => void;
}

const Navigation: React.FC<NavigationProps> = ({ className = '', onLinkClick }) => {
  const location = useLocation();

  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/order', label: 'Order' },
    { to: '/locations', label: 'Locations' },
    { to: '/about', label: 'About' },
    { to: '/contact', label: 'Contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className={className}>
      {navLinks.map((link) => (
        <Link
          key={link.to}
          to={link.to}
          onClick={onLinkClick}
          className={`hover:text-red-300 transition-colors ${
            isActive(link.to) ? 'text-red-300' : ''
          }`}
        >
          {link.label}
        </Link>
      ))}
    </nav>
  );
};

export default Navigation;