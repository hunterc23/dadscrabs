export interface Order {
  id?: number;
  name?: string;
  phone: string;
  email: string;
  address: string;
  crab_size: string;
  order_type: 'delivery' | 'pickup';
  quantity: number;
  additional_info?: string;
  created_at?: string;
}

export interface BulkInquiry {
  id?: number;
  business_name: string;
  phone: string;
  email: string;
  short_note?: string;
  created_at?: string;
}

export interface Contact {
  id?: number;
  name: string;
  email: string;
  message: string;
  created_at?: string;
}

export interface CrabOption {
  id: string;
  name: string;
  size: string;
  dozen: string;
  price: number;
  available: boolean;
  image: string;
  alt: string;
}