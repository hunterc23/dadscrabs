// Google Maps utilities for delivery area checking

export interface DeliveryCheckResult {
  isInServiceArea: boolean;
  address: string;
  message: string;
}

// Eastern Shore service area bounds (east of Bay Bridge)
export const EASTERN_SHORE_BOUNDS = {
  north: 39.2,
  south: 37.8,
  east: -74.8,
  west: -76.2, // Bay Bridge longitude (approximate)
};

// Check if coordinates are in Eastern Shore service area
export const isInEasternShore = (lat: number, lng: number): boolean => {
  return (
    lat >= EASTERN_SHORE_BOUNDS.south &&
    lat <= EASTERN_SHORE_BOUNDS.north &&
    lng >= EASTERN_SHORE_BOUNDS.west &&
    lng <= EASTERN_SHORE_BOUNDS.east
  );
};

// Geocode address and check if it's in service area
export const checkDeliveryLocation = async (address: string): Promise<DeliveryCheckResult> => {
  return new Promise((resolve) => {
    if (!window.google || !window.google.maps) {
      resolve({
        isInServiceArea: false,
        address,
        message: 'Google Maps is not loaded. Please try again.',
      });
      return;
    }

    const geocoder = new window.google.maps.Geocoder();
    
    geocoder.geocode({ address }, (results, status) => {
      if (status === 'OK' && results && results[0]) {
        const location = results[0].geometry.location;
        const lat = location.lat();
        const lng = location.lng();
        const formattedAddress = results[0].formatted_address;
        
        const inServiceArea = isInEasternShore(lat, lng);
        
        resolve({
          isInServiceArea: inServiceArea,
          address: formattedAddress,
          message: inServiceArea 
            ? 'Great! We deliver to your area with no delivery fees.'
            : 'Sorry, this address is outside our delivery area. We serve areas east of the Bay Bridge including Cambridge, Ocean City, Easton, Fenwick DE, and Bethany DE.',
        });
      } else {
        resolve({
          isInServiceArea: false,
          address,
          message: 'Could not verify this address. Please check the spelling and try again.',
        });
      }
    });
  });
};