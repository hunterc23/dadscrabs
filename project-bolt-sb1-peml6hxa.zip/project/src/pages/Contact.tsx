import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Mail, Phone, MapPin, Send, Users } from 'lucide-react';
import { supabase } from '../utils/supabase';
import { trackEvent, trackPageView } from '../utils/analytics';
import type { Contact, BulkInquiry } from '../types';

const Contact: React.FC = () => {
  const [searchParams] = useSearchParams();
  const isBulk = searchParams.get('type') === 'bulk';
  
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  
  // Regular contact form
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [message, setMessage] = useState<string>('');
  
  // Bulk inquiry form
  const [businessName, setBusinessName] = useState<string>('');
  const [bulkPhone, setBulkPhone] = useState<string>('');
  const [bulkEmail, setBulkEmail] = useState<string>('');
  const [shortNote, setShortNote] = useState<string>('Inquiry for bulk crab order pricing and availability');

  useEffect(() => {
    trackPageView('/contact');
  }, []);

  const validateContactForm = () => {
    if (!name.trim()) return false;
    if (!email.trim() || !email.includes('@')) return false;
    if (!message.trim()) return false;
    return true;
  };

  const validateBulkForm = () => {
    if (!businessName.trim()) return false;
    if (!bulkPhone.trim()) return false;
    if (!bulkEmail.trim() || !bulkEmail.includes('@')) return false;
    return true;
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateContactForm()) {
      alert('Please fill in all required fields with valid information.');
      return;
    }

    setIsSubmitting(true);

    try {
      const contactData: Contact = {
        name,
        email,
        message,
      };

      const { error } = await supabase
        .from('contacts')
        .insert([contactData]);

      if (error) {
        console.error('Error submitting contact:', error);
        alert('There was an error submitting your message. Please try again.');
        return;
      }

      trackEvent('form_submit', { form_type: 'contact' });
      alert('Message submitted successfully! We\'ll get back to you soon.');
      
      // Reset form
      setName('');
      setEmail('');
      setMessage('');

    } catch (error) {
      console.error('Error submitting contact:', error);
      alert('There was an error submitting your message. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleBulkSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateBulkForm()) {
      alert('Please fill in all required fields with valid information.');
      return;
    }

    setIsSubmitting(true);

    try {
      const bulkData: BulkInquiry = {
        business_name: businessName,
        phone: bulkPhone,
        email: bulkEmail,
        short_note: shortNote,
      };

      const { error } = await supabase
        .from('bulk_inquiries')
        .insert([bulkData]);

      if (error) {
        console.error('Error submitting bulk inquiry:', error);
        alert('There was an error submitting your inquiry. Please try again.');
        return;
      }

      trackEvent('bulk_inquiry_submitted', { business_name: businessName });
      alert('Bulk inquiry submitted successfully! We\'ll contact you with custom pricing.');
      
      // Reset form
      setBusinessName('');
      setBulkPhone('');
      setBulkEmail('');
      setShortNote('Inquiry for bulk crab order pricing and availability');

    } catch (error) {
      console.error('Error submitting bulk inquiry:', error);
      alert('There was an error submitting your inquiry. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
              {isBulk ? 'Wholesale Inquiry' : 'Contact Us'}
            </h1>
            <p className="text-lg text-gray-700">
              {isBulk 
                ? 'Get custom pricing and discounts for bulk orders'
                : 'Get in touch with any questions about our fresh Maryland crabs'
              }
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Contact Form */}
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <div className="flex items-center space-x-2 mb-6">
                {isBulk ? <Users className="h-6 w-6 text-blue-600" /> : <Mail className="h-6 w-6 text-blue-600" />}
                <h2 className="text-2xl font-bold text-blue-900">
                  {isBulk ? 'Wholesale Inquiry Form' : 'Send us a Message'}
                </h2>
              </div>

              {isBulk ? (
                <form onSubmit={handleBulkSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Business Name *
                    </label>
                    <input
                      type="text"
                      value={businessName}
                      onChange={(e) => setBusinessName(e.target.value)}
                      placeholder="Your business or restaurant name"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      value={bulkPhone}
                      onChange={(e) => setBulkPhone(e.target.value)}
                      placeholder="(xxx) xxx-xxxx"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={bulkEmail}
                      onChange={(e) => setBulkEmail(e.target.value)}
                      placeholder="business@email.com"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Short Note
                    </label>
                    <textarea
                      value={shortNote}
                      onChange={(e) => setShortNote(e.target.value)}
                      rows={4}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-bold py-4 px-6 rounded-lg transition-colors flex items-center justify-center space-x-2"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                        <span>Submitting...</span>
                      </>
                    ) : (
                      <>
                        <Send className="h-5 w-5" />
                        <span>Submit Inquiry</span>
                      </>
                    )}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Name *
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Your name"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email *
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="your@email.com"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Message *
                    </label>
                    <textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="How can we help you?"
                      rows={6}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white font-bold py-4 px-6 rounded-lg transition-colors flex items-center justify-center space-x-2"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                        <span>Sending...</span>
                      </>
                    ) : (
                      <>
                        <Send className="h-5 w-5" />
                        <span>Send Message</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>

            {/* Contact Information */}
            <div className="space-y-6">
              <div className="bg-white p-8 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold text-blue-900 mb-6">Get in Touch</h2>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Phone className="h-6 w-6 text-red-500 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-gray-900">[INSERT PHONE NUMBER]</p>
                      <p className="text-sm text-gray-600">Call for immediate assistance</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Mail className="h-6 w-6 text-red-500 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-gray-900">info@dadscrabs.com</p>
                      <p className="text-sm text-gray-600">General inquiries</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-6 w-6 text-red-500 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-gray-900">Cambridge, MD</p>
                      <p className="text-sm text-gray-600">Eastern Shore pickup location</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                <h3 className="text-xl font-bold text-blue-900 mb-3">Business Hours</h3>
                <div className="space-y-1 text-gray-700">
                  <p>Monday - Saturday: 8:00 AM - 6:00 PM</p>
                  <p>Sunday: 10:00 AM - 4:00 PM</p>
                  <p className="text-sm text-blue-600 mt-2">
                    * Hours may vary during crab season
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;