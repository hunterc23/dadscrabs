import React, { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import DeliveryChecker from '../components/DeliveryChecker';
import { trackPageView } from '../utils/analytics';

const Locations: React.FC = () => {
  const mapRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    trackPageView('/locations');
  }, []);

  useEffect(() => {
    const initMap = () => {
      if (!window.google || !mapRef.current) return;

      const map = new window.google.maps.Map(mapRef.current, {
        center: { lat: 38.5, lng: -75.9 },
        zoom: 10,
        styles: [
          {
            featureType: 'water',
            elementType: 'geometry',
            stylers: [{ color: '#1e40af' }]
          },
          {
            featureType: 'landscape',
            elementType: 'geometry',
            stylers: [{ color: '#f3f4f6' }]
          }
        ]
      });

      // Cambridge MD marker
      new window.google.maps.Marker({
        position: { lat: 38.5632, lng: -76.0788 },
        map,
        title: 'Dads Crabs - Cambridge Location',
        icon: {
          url: '/images/map-pin.png',
          scaledSize: new window.google.maps.Size(32, 32),
          anchor: new window.google.maps.Point(16, 32)
        }
      });

      // Ocean City MD marker
      new window.google.maps.Marker({
        position: { lat: 38.3365, lng: -75.0850 },
        map,
        title: 'Dads Crabs - Ocean City Service Area',
        icon: {
          url: '/images/map-pin.png',
          scaledSize: new window.google.maps.Size(32, 32),
          anchor: new window.google.maps.Point(16, 32)
        }
      });
    };

    if (window.google) {
      initMap();
    } else {
      const checkGoogleMaps = setInterval(() => {
        if (window.google) {
          clearInterval(checkGoogleMaps);
          initMap();
        }
      }, 100);

      return () => clearInterval(checkGoogleMaps);
    }
  }, []);

  const handleDeliveryVerified = (data: { name: string; phone: string; address: string }) => {
    // Navigate to order page with pre-filled data
    navigate('/order', { 
      state: { 
        prefilledData: data,
        fromDeliveryCheck: true 
      } 
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
              Our Locations
            </h1>
            <p className="text-lg text-gray-700">
              Serving Maryland's Eastern Shore and Delaware beaches
            </p>
          </div>

          {/* Delivery Location Checker */}
          <div className="mb-8">
            <DeliveryChecker onVerified={handleDeliveryVerified} />
          </div>

          {/* Map */}
          <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-8">
            <div 
              ref={mapRef} 
              className="w-full h-96 md:h-[500px]"
              style={{ minHeight: '400px' }}
            />
          </div>

          {/* Location Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h2 className="text-xl font-bold text-blue-900 mb-4">Cambridge, MD</h2>
              <p className="text-gray-700 mb-4">
                Our main location and pickup point
              </p>
              <div className="space-y-2 text-gray-600">
                <p>📍 Cambridge, Maryland</p>
                <p>📞 [INSERT PHONE NUMBER]</p>
                <p>✉️ info@dadscrabs.com</p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h2 className="text-xl font-bold text-blue-900 mb-4">Delivery Areas</h2>
              <p className="text-gray-700 mb-4">
                Free delivery to Eastern Shore locations
              </p>
              <ul className="space-y-1 text-gray-600">
                <li>• Cambridge, MD</li>
                <li>• Ocean City, MD</li>
                <li>• Easton, MD</li>
                <li>• Fenwick, DE</li>
                <li>• Bethany, DE</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Locations;