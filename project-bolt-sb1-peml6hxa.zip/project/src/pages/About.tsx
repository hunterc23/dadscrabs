import React, { useEffect } from 'react';
import { Waves, Heart, Users } from 'lucide-react';
import { trackPageView } from '../utils/analytics';

const About: React.FC = () => {
  useEffect(() => {
    trackPageView('/about');
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
              About Dads Crabs
            </h1>
            <p className="text-lg text-gray-700">
              A family tradition of bringing fresh Maryland blue crabs to your table
            </p>
          </div>

          {/* Main Content */}
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <img
              src="/images/hero-crabs.jpg"
              alt="Fresh Maryland Blue Crabs in Bushel"
              className="w-full h-64 object-cover"
              loading="lazy"
            />
            
            <div className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                <div className="text-center">
                  <Waves className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-blue-900 mb-2">Chesapeake Bay</h3>
                  <p className="text-gray-700">
                    Sourced directly from the pristine waters of the Chesapeake Bay
                  </p>
                </div>
                
                <div className="text-center">
                  <Heart className="h-12 w-12 text-red-600 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-blue-900 mb-2">Family-Owned</h3>
                  <p className="text-gray-700">
                    Multi-generational family business with deep Eastern Shore roots
                  </p>
                </div>
                
                <div className="text-center">
                  <Users className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-blue-900 mb-2">Local Watermen</h3>
                  <p className="text-gray-700">
                    Partnering with trusted local crabbers who know these waters
                  </p>
                </div>
              </div>

              <div className="prose prose-lg max-w-none">
                <h2 className="text-2xl font-bold text-blue-900 mb-4">Our Story</h2>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  For generations, our family has been deeply connected to Maryland's Eastern Shore 
                  and the bountiful waters of the Chesapeake Bay. What started as a passion for 
                  sharing the finest blue crabs with friends and neighbors has grown into a 
                  trusted source for locals, visitors, and wholesale customers throughout the region.
                </p>

                <p className="text-gray-700 mb-6 leading-relaxed">
                  We work directly with experienced watermen who have spent their lives on these 
                  waters, ensuring that every crab we deliver meets our high standards for quality 
                  and freshness. From the moment they're pulled from the Bay to when they arrive 
                  at your door, our crabs are handled with care and kept live for maximum flavor.
                </p>

                <h2 className="text-2xl font-bold text-blue-900 mb-4">Our Commitment</h2>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  Whether you're a local family looking for a weekend feast, tourists wanting 
                  an authentic Maryland experience, or a restaurant needing a reliable wholesale 
                  supplier, we're committed to providing the freshest Maryland blue crabs with 
                  honest pricing and reliable service.
                </p>

                <div className="bg-blue-50 p-6 rounded-lg">
                  <h3 className="text-xl font-bold text-blue-900 mb-2">Why Choose Dads Crabs?</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li>✓ Fresh, live crabs caught daily from the Chesapeake Bay</li>
                    <li>✓ Free delivery throughout Eastern Shore communities</li>
                    <li>✓ Competitive pricing with bulk discounts available</li>
                    <li>✓ Family-owned business you can trust</li>
                    <li>✓ Supporting local Maryland watermen</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;