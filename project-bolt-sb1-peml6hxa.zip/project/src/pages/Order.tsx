import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Users, CheckCircle, MapPin, ArrowLeft } from 'lucide-react';
import { supabase } from '../utils/supabase';
import { trackEvent, trackPageView } from '../utils/analytics';
import BulkInquiryForm from '../components/BulkInquiryForm';
import DeliveryChecker from '../components/DeliveryChecker';
import type { Order, CrabOption } from '../types';

const OrderPage: React.FC = () => {
  const location = useLocation();
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [orderType, setOrderType] = useState<'delivery' | 'pickup'>('delivery');
  const [quantity, setQuantity] = useState<number>(1);
  const [showForm, setShowForm] = useState<boolean>(false);
  const [showBulkForm, setShowBulkForm] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Form fields
  const [name, setName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [additionalInfo, setAdditionalInfo] = useState<string>('');

  // Check for pre-filled data from delivery checker
  useEffect(() => {
    const state = location.state as any;
    if (state?.prefilledData && state?.fromDeliveryCheck) {
      const { name: prefillName, phone: prefillPhone, address: prefillAddress } = state.prefilledData;
      setName(prefillName);
      setPhone(prefillPhone);
      setAddress(prefillAddress);
      setOrderType('delivery');
      // Clear the state to prevent re-filling on refresh
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  useEffect(() => {
    trackPageView('/order');
  }, []);

  useEffect(() => {
    // Initialize Google Places Autocomplete when address input is available
    if (showForm && orderType === 'delivery') {
      const initializeAutocomplete = () => {
        if (!window.google || !window.google.maps || !window.google.maps.places) return;

        const input = document.getElementById('address-input') as HTMLInputElement;
        if (!input) return;

        // Eastern Shore bounds
        const easternShoreBounds = new window.google.maps.LatLngBounds(
          new window.google.maps.LatLng(37.8, -76.8), // Southwest
          new window.google.maps.LatLng(39.2, -74.8)  // Northeast
        );

        const autocomplete = new window.google.maps.places.Autocomplete(input, {
          bounds: easternShoreBounds,
          componentRestrictions: { country: 'us' },
          fields: ['formatted_address'],
        });

        autocomplete.addListener('place_changed', () => {
          const place = autocomplete.getPlace();
          if (place.formatted_address) {
            setAddress(place.formatted_address);
          }
        });
      };

      // Wait for Google Maps to load
      if (window.google) {
        initializeAutocomplete();
      } else {
        const checkGoogleMaps = setInterval(() => {
          if (window.google) {
            clearInterval(checkGoogleMaps);
            initializeAutocomplete();
          }
        }, 100);

        return () => clearInterval(checkGoogleMaps);
      }
    }
  }, [showForm, orderType]);

  const crabOptions: CrabOption[] = [
    { id: 'small', name: 'Small Bushel', size: '5-5.75"', dozen: '~7-8 dozen', price: 220, available: true, image: '/images/small-bushel.jpg', alt: 'Small Bushel Maryland Blue Crabs' },
    { id: 'medium', name: 'Medium Bushel', size: '5.75-6.25"', dozen: '~6-7 dozen', price: 270, available: true, image: '/images/medium-bushel.jpg', alt: 'Medium Bushel Maryland Blue Crabs' },
    { id: 'large', name: 'Large Bushel', size: '6.25-7"', dozen: '~5-6 dozen', price: 320, available: true, image: '/images/large-bushel.jpg', alt: 'Large Bushel Maryland Blue Crabs' },
    { id: 'jumbo', name: 'Jumbo Bushel', size: '7"+ crabs', dozen: '~4-5 dozen', price: 370, available: true, image: '/images/jumbo-bushel.jpg', alt: 'Jumbo Bushel Maryland Blue Crabs' },
  ];

  const handleSizeSelection = (size: string) => {
    setSelectedSize(size);
    setShowForm(true);
    setShowBulkForm(false);
    trackEvent('button_click', { label: `crab_size_${size}` });
  };

  const handleBulkOrderClick = () => {
    setShowBulkForm(true);
    setShowForm(false);
    setSelectedSize('');
    trackEvent('button_click', { label: 'bulk_order' });
  };

  const handleBackToSelection = () => {
    setShowForm(false);
    setShowBulkForm(false);
    setSelectedSize('');
    // Reset form
    setName('');
    setPhone('');
    setEmail('');
    setAddress('');
    setAdditionalInfo('');
    setQuantity(1);
  };

  const validateForm = () => {
    if (!name.trim()) return false;
    if (!phone.trim()) return false;
    if (!email.trim() || !email.includes('@')) return false;
    if (orderType === 'delivery' && !address.trim()) return false;
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      alert('Please fill in all required fields including name, phone, and email with valid information.');
      return;
    }

    setIsSubmitting(true);

    try {
      const orderData: Order = {
        name,
        phone,
        email,
        address: orderType === 'pickup' ? 'Pickup at Cambridge, MD location' : address,
        crab_size: selectedSize,
        order_type: orderType,
        quantity,
        additional_info: additionalInfo,
      };

      const { error } = await supabase
        .from('orders')
        .insert([orderData]);

      if (error) {
        console.error('Error submitting order:', error);
        alert('There was an error submitting your order. Please try again.');
        return;
      }

      trackEvent('order_submitted', {
        crab_size: selectedSize,
        order_type: orderType,
        quantity,
        anonymized_address_region: orderType === 'delivery' ? 'Eastern Shore' : 'Pickup'
      });

      alert('Order submitted—details forwarded to admin email');
      
      // Reset form
      handleBackToSelection();

    } catch (error) {
      console.error('Error submitting order:', error);
      alert('There was an error submitting your order. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeliveryVerified = (data: { name: string; phone: string; address: string }) => {
    setName(data.name);
    setPhone(data.phone);
    setAddress(data.address);
    setOrderType('delivery');
  };

  const handleStripeClick = () => {
    alert('Stripe integration coming soon—contact us.');
  };

  const selectedCrab = crabOptions.find(option => option.id === selectedSize);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
              Order Fresh Maryland Blue Crabs
            </h1>
            <p className="text-lg text-gray-700">
              All crabs are live and fresh from the Chesapeake Bay
            </p>
          </div>

          {/* Back button when form is shown */}
          {(showForm || showBulkForm) && (
            <button
              onClick={handleBackToSelection}
              className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 mb-6 transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
              <span>Back to crab selection</span>
            </button>
          )}

          {/* Delivery Location Checker - only show if no form is active */}
          {!showForm && !showBulkForm && (
            <div className="mb-8">
              <DeliveryChecker 
                onVerified={handleDeliveryVerified}
                showTitle={false}
                className="border-2 border-blue-200"
              />
            </div>
          )}

          {/* Bulk Inquiry Form */}
          {showBulkForm && (
            <BulkInquiryForm onClose={handleBackToSelection} />
          )}

          {/* Regular Order Form */}
          {showForm && selectedCrab && (
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <h2 className="text-2xl font-bold text-blue-900 mb-6">Order Details</h2>
              
              {/* Selected Item Summary */}
              <div className="bg-blue-50 p-4 rounded-lg mb-6">
                <h3 className="font-bold text-blue-900">{selectedCrab.name}</h3>
                <p className="text-blue-700">{selectedCrab.size} • {selectedCrab.dozen}</p>
                <p className="text-2xl font-bold text-red-600">${selectedCrab.price}</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Quantity */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Quantity
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                {/* Order Type */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-4">
                    Order Type
                  </label>
                  <div className="space-y-3">
                    <label className="flex items-start space-x-3 cursor-pointer">
                      <input
                        type="radio"
                        value="delivery"
                        checked={orderType === 'delivery'}
                        onChange={(e) => setOrderType(e.target.value as 'delivery' | 'pickup')}
                        className="mt-1"
                      />
                      <div>
                        <span className="font-medium text-gray-900">Delivery</span>
                        <p className="text-sm text-gray-600">
                          No Fees - Eastern Shore areas including Cambridge, Ocean City, Easton, Fenwick DE, Bethany DE
                        </p>
                      </div>
                    </label>
                    <label className="flex items-start space-x-3 cursor-pointer">
                      <input
                        type="radio"
                        value="pickup"
                        checked={orderType === 'pickup'}
                        onChange={(e) => setOrderType(e.target.value as 'delivery' | 'pickup')}
                        className="mt-1"
                      />
                      <div>
                        <span className="font-medium text-gray-900">Pickup</span>
                        <p className="text-sm text-gray-600">
                          Pick up at our Cambridge, MD location
                        </p>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Address (if delivery) */}
                {orderType === 'delivery' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <MapPin className="inline h-4 w-4 mr-1" />
                      Delivery Address *
                    </label>
                    <input
                      type="text"
                      id="address-input"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="Start typing your address..."
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      required
                    />
                  </div>
                )}

                {/* Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your name"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="(xxx) xxx-xxxx"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                </div>

                {/* Email */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                </div>

                {/* Additional Info */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Additional Information
                  </label>
                  <textarea
                    value={additionalInfo}
                    onChange={(e) => setAdditionalInfo(e.target.value)}
                    placeholder="Special instructions, preferred delivery time, etc."
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                  />
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white font-bold py-4 px-6 rounded-lg transition-colors flex items-center justify-center space-x-2"
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                      <span>Submitting...</span>
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="h-5 w-5" />
                      <span>Submit Order</span>
                    </>
                  )}
                </button>

                {/* Stripe Placeholder */}
                <button
                  type="button"
                  onClick={handleStripeClick}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-4 px-6 rounded-lg transition-colors"
                >
                  Proceed to Payment (Coming Soon)
                </button>
              </form>
            </div>
          )}

          {/* Crab Selection */}
          {!showForm && !showBulkForm && (
            <div className="mb-12">
              <h2 className="text-2xl font-bold text-blue-900 mb-6">Select Your Crabs</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                {crabOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => handleSizeSelection(option.id)}
                    disabled={!option.available}
                    className={`group relative rounded-3xl border-2 transition-all duration-500 text-left transform hover:scale-[1.03] overflow-hidden backdrop-blur-xl shadow-2xl hover:shadow-3xl ${
                      selectedSize === option.id
                        ? 'border-red-500/80 bg-gradient-to-br from-red-50/80 via-white/60 to-red-100/40 shadow-red-200/50 ring-4 ring-red-300/30'
                        : option.available
                        ? 'border-blue-200/50 bg-gradient-to-br from-white/70 via-blue-50/30 to-white/50 hover:border-blue-400/70 hover:bg-gradient-to-br hover:from-white/80 hover:via-blue-50/50 hover:to-blue-100/30 hover:ring-4 hover:ring-blue-200/20'
                        : 'border-gray-300/30 bg-gradient-to-br from-gray-100/50 to-gray-200/30 cursor-not-allowed opacity-60'
                    }`}
                  >
                    {/* Glassy overlay effect */}
                    <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-white/10 pointer-events-none rounded-3xl"></div>
                    
                    {/* Product Image */}
                    <div className="relative w-full h-72 sm:h-64 md:h-60 lg:h-56 flex items-center justify-center border-b border-white/30 overflow-hidden">
                      <img
                        src={option.image}
                        alt={option.alt}
                       className="w-full h-full object-cover object-bottom rounded-t-3xl shadow-lg group-hover:scale-105 transition-transform duration-500"
                        loading="lazy"
                      />
                      {selectedSize === option.id && (
                        <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-xl rounded-full p-3 shadow-2xl ring-2 ring-red-300/60 animate-pulse">
                          <CheckCircle className="h-6 w-6 text-red-600" />
                        </div>
                      )}
                      
                      {/* Enhanced Chesapeake Bay Wave Pattern */}
                      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-blue-900/20 via-blue-600/10 to-transparent"></div>
                      <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-blue-800/15 via-blue-500/8 to-transparent"></div>
                      
                      {/* Maryland Bay Reflection Effects */}
                      <div className="absolute bottom-3 left-6 right-6 h-1 bg-gradient-to-r from-transparent via-blue-400/40 to-transparent rounded-full"></div>
                      <div className="absolute bottom-1 left-8 right-8 h-0.5 bg-gradient-to-r from-transparent via-blue-300/30 to-transparent rounded-full"></div>
                      
                      {/* Fresh from Bay indicator */}
                      <div className="absolute top-4 left-4 bg-blue-600/90 backdrop-blur-md text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg border border-blue-400/30">
                        Fresh Daily
                      </div>
                    </div>
                    
                    {/* Product Details */}
                    <div className="relative p-6 bg-gradient-to-br from-white/70 via-white/50 to-blue-50/40 backdrop-blur-xl">
                      {/* Glassy inner overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-white/10 via-transparent to-white/20 pointer-events-none"></div>
                      
                      <div className="relative z-10">
                        <h3 className="text-xl md:text-lg font-bold text-blue-900 mb-3 flex items-center justify-between">
                        {option.name}
                          <span className="text-xs bg-gradient-to-r from-blue-100/90 to-blue-50/80 text-blue-800 px-3 py-1.5 rounded-full font-bold backdrop-blur-md border border-blue-200/60 shadow-sm">
                            Live
                          </span>
                        </h3>
                        
                        <p className="text-gray-700 mb-4 font-semibold text-base flex items-center">
                          <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                          {option.size} • {option.dozen}
                        </p>
                        
                        <div className="flex items-center justify-between mb-4">
                          <p className="text-3xl md:text-2xl font-bold text-red-600 drop-shadow-md">${option.price}</p>
                          <div className="text-xs text-blue-700 font-bold bg-gradient-to-r from-blue-50/90 to-white/70 px-4 py-2 rounded-full backdrop-blur-md border border-blue-200/50 shadow-sm">
                            🌊 Chesapeake Bay
                          </div>
                        </div>
                        
                        {/* Enhanced Maryland Touch - Eastern Shore Badge */}
                        <div className="flex items-center justify-center">
                          <div className="text-sm text-blue-700 font-bold bg-gradient-to-r from-blue-50/90 via-white/70 to-blue-50/90 px-5 py-2 rounded-full border border-blue-200/40 backdrop-blur-md shadow-lg">
                            🦀 Eastern Shore Tradition
                          </div>
                        </div>
                        
                        {!option.available && (
                          <div className="mt-4 text-center">
                            <p className="text-red-600 font-bold bg-gradient-to-r from-red-50/90 to-white/70 px-6 py-3 rounded-full backdrop-blur-md border border-red-200/60 shadow-lg">
                              Coming Soon
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>

              {/* Steamed Option - Disabled */}
              <div className="mb-8 p-6 bg-gradient-to-br from-gray-100/50 via-white/30 to-gray-200/40 backdrop-blur-xl rounded-3xl border-2 border-gray-300/40 opacity-60 shadow-xl">
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-white/10 pointer-events-none rounded-3xl"></div>
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-xl font-bold text-gray-700 flex items-center">
                      <span className="w-3 h-3 bg-gray-400 rounded-full mr-3"></span>
                      Steamed Crabs
                    </h3>
                    <p className="text-gray-600 ml-6">🔥 Hot & seasoned with Old Bay</p>
                  </div>
                  <div className="text-lg font-bold text-gray-600 bg-gray-200/80 px-4 py-2 rounded-full backdrop-blur-md">
                    Coming Soon
                  </div>
                </div>
              </div>

              {/* Bulk Order Button */}
              <div className="relative p-8 bg-gradient-to-br from-blue-50/70 via-white/40 to-blue-100/50 backdrop-blur-xl rounded-3xl border-2 border-blue-200/60 shadow-2xl hover:shadow-3xl transition-all duration-500 group">
                {/* Enhanced glassy overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-white/30 via-transparent to-white/15 pointer-events-none rounded-3xl"></div>
                <div className="absolute inset-0 bg-gradient-to-t from-blue-100/20 via-transparent to-white/20 pointer-events-none rounded-3xl"></div>
                
                <div className="flex flex-col md:flex-row items-center justify-between">
                  <div className="relative z-10 mb-6 md:mb-0 text-center md:text-left">
                    <div className="flex items-center justify-center md:justify-start space-x-2 mb-2">
                      <Users className="h-7 w-7 text-blue-600" />
                      <h3 className="text-2xl font-bold text-blue-900">Wholesale Orders</h3>
                      <span className="text-xs bg-gradient-to-r from-blue-100/90 to-blue-50/80 text-blue-800 px-4 py-1.5 rounded-full font-bold backdrop-blur-md border border-blue-200/60 shadow-sm">
                        Local
                      </span>
                    </div>
                    <p className="text-blue-800 font-bold text-lg mb-2">Contact for Custom Pricing & Discounts</p>
                    <p className="text-blue-600 font-semibold flex items-center justify-center md:justify-start">
                      <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                      🏪 Supporting Local Maryland Businesses
                    </p>
                  </div>
                  <button
                    onClick={handleBulkOrderClick}
                    className="relative z-10 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold py-5 px-10 rounded-2xl transition-all duration-500 transform hover:scale-110 shadow-2xl hover:shadow-3xl backdrop-blur-md border border-blue-500/30 group-hover:ring-4 group-hover:ring-blue-300/20"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-transparent to-white/10 rounded-2xl pointer-events-none"></div>
                    Bulk Order Inquiry
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default OrderPage;