import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Waves, Star, Truck } from 'lucide-react';
import { trackEvent, trackPageView } from '../utils/analytics';

const Home: React.FC = () => {
  useEffect(() => {
    trackPageView('/');
  }, []);

  const handleOrderNowClick = () => {
    trackEvent('button_click', { label: 'hero_order_now' });
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-blue-600 to-blue-800 text-white">
        {/* Hero Background Image */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: 'url(/images/hero-crabs.jpg)' }}
          role="img"
          aria-label="Fresh Maryland Blue Crabs in Bushel"
        ></div>
        {/* Blue Overlay for Text Readability */}
        <div className="absolute inset-0 bg-blue-900" style={{ opacity: 0.5 }}></div>
        <div className="relative container mx-auto px-4 py-20 md:py-32">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Fresh Live Maryland Blue Crabs
              <span className="block text-red-300">from the Eastern Shore!</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">
              Family-owned and sourced directly from the Chesapeake Bay
            </p>
            <Link
              to="/order"
              onClick={handleOrderNowClick}
              className="inline-flex items-center bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-8 rounded-lg text-lg transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              Order Now
              <ArrowRight className="ml-2 h-6 w-6" />
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 120" fill="none" className="w-full h-12 text-white">
            <path
              d="M0,64L48,74.7C96,85,192,107,288,112C384,117,480,107,576,90.7C672,75,768,53,864,53.3C960,53,1056,75,1152,80C1248,85,1344,75,1392,69.3L1440,64L1440,120L1392,120C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z"
              fill="currentColor"
            />
          </svg>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-6">
                  Family-Owned Tradition
                </h2>
                <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                  For generations, our family has been bringing the finest Maryland blue crabs 
                  from the Chesapeake Bay directly to your table. We source our crabs from 
                  trusted local watermen who know these waters like the back of their hands.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                  <div className="text-center">
                    <Waves className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                    <h3 className="font-semibold text-blue-900">Fresh Daily</h3>
                    <p className="text-sm text-gray-600">Caught fresh from the Bay</p>
                  </div>
                  <div className="text-center">
                    <Star className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                    <h3 className="font-semibold text-blue-900">Premium Quality</h3>
                    <p className="text-sm text-gray-600">Hand-selected crabs</p>
                  </div>
                  <div className="text-center">
                    <Truck className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                    <h3 className="font-semibold text-blue-900">Free Delivery</h3>
                    <p className="text-sm text-gray-600">Eastern Shore areas</p>
                  </div>
                </div>
              </div>
              <div className="relative">
                <img
                  src="/images/hero-crabs.jpg"
                  alt="Fresh Maryland Blue Crabs in Bushel"
                  className="w-full rounded-lg shadow-xl"
                  loading="lazy"
                />
                <div className="absolute -bottom-4 -right-4 bg-red-600 text-white p-4 rounded-lg shadow-lg">
                  <p className="font-bold text-lg">Live & Fresh</p>
                  <p className="text-sm">Guaranteed</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-6">
            Ready to Order Fresh Crabs?
          </h2>
          <p className="text-xl text-gray-700 mb-8">
            Choose from small to jumbo sizes - perfect for any occasion
          </p>
          <Link
            to="/order"
            onClick={handleOrderNowClick}
            className="inline-flex items-center bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-8 rounded-lg text-lg transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            Start Your Order
            <ArrowRight className="ml-2 h-6 w-6" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;